library(testthat)
library(IRdisplay)

test_check('IRdisplay')
