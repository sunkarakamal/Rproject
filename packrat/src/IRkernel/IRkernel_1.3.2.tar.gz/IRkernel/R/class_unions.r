setClassUnion('functionOrNULL', members = c('function', 'NULL'))
setClassUnion('recordedplotOrNULL', members = c('recordedplot', 'NULL'))
setClassUnion('listOrNULL', members = c('list', 'NULL'))
